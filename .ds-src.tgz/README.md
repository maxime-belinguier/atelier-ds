# DS-Studio V2

Un atelier **web local** pour explorer, modifier et faire évoluer un Design System.
Ce starter pédagogique est conçu pour devenir **votre outil**, pas pour dicter vos
choix. Version personnalisée pour **Gutt** (PFE) : panneau Design System (tokens,
composants, écrans) et panneau Aperçu redimensionnables, assistant en bulle flottante.

**Branché à Claude et à Figma** (via Claude Code et ton compte), et toujours utilisable
à la main, hors ligne. Une IA cloud nécessite un compte, Internet et du quota.

## Installer et lancer

Prérequis : **Node.js 22.12+**, npm fourni avec Node et un navigateur moderne.
Node LTS 22.23.4 est la version testée ; [.nvmrc](.nvmrc) la fixe pour les outils compatibles.
Téléchargez Node depuis [le site officiel](https://nodejs.org/en/download).
Git est facultatif si vous téléchargez une archive. Aucun Python, Docker, compte
Figma ou abonnement IA n’est nécessaire pour démarrer.

1. Clonez ou décompressez **tout le dossier**, puis double-cliquez sur le lanceur :

   | Système | Fichier                                                                                             |
   | ------- | --------------------------------------------------------------------------------------------------- |
   | Linux   | **DS-Studio.desktop** (icône de développement ; autoriser l’exécution / faire confiance si demandé) |
   | macOS   | **DS-Studio.app**, à laisser dans le dossier du projet                                              |
   | Windows | **DS-Studio.vbs**, sans fenêtre de console                                                          |

2. Si Node manque, le guide graphique local s’ouvre. Le lanceur cherche aussi les
   installations utilisateur hors PATH, sans exécuter vos profils shell.
   Il ne télécharge pas Node et ne lance aucune commande administrateur.
3. Au premier lancement, cliquez **Installer / compiler…**, puis confirmez
   explicitement le téléchargement des dépendances et la compilation. Internet
   est nécessaire. Le journal et les erreurs restent visibles dans le panneau.
4. Cliquez **Démarrer DS-Studio**, puis **Ouvrir DS-Studio**. Aux lancements suivants,
   un double-clic ouvre le panneau et démarre / ouvre automatiquement l’atelier
   s’il est prêt et arrêté. S’il est déjà actif, il retrouve son panneau sans
   créer un second serveur.
5. Cliquez **Arrêter DS-Studio** dans le panneau pour arrêter le vrai serveur.
   **Redémarrer** conserve les données. **Arrêter et quitter le lanceur** ferme
   aussi son petit service local. Fermer le navigateur n’arrête pas le serveur :
   un nouveau double-clic retrouve les commandes.

Le panneau utilise votre navigateur, pas Electron. Aucun runtime supplémentaire
obligatoire. [Guide graphique hors ligne](launcher/INSTALLATION.html) et
[dépannage détaillé](docs/LAUNCHER.md). Le contrôleur est **testé en CI sur les trois OS**. Les entrées Finder et Windows
Script Host restent **à tester sur les postes réels** : application Mac non signée,
Windows Script Host nécessaire au `.vbs`. Les protections de l’établissement
peuvent bloquer ces fichiers ; ne les désactivez pas. Gardez les lanceurs dans
le projet ; créez un raccourci système plutôt que de déplacer le fichier seul.

### Le terminal reste disponible

Depuis le dossier du projet :

```sh
npm ci
npm run build
npm start
```

Ouvrez **http://127.0.0.1:4310** (pas `localhost`, le contrôle d’hôte est strict).
Laissez ce terminal ouvert. **Ctrl+C** arrête le serveur ; fermer l’onglet ne l’arrête pas.
Les scripts historiques `./start.sh`, `./start.command` et `start.cmd` restent
disponibles après installation et compilation ; ils affichent l’URL sans ouvrir
le navigateur. `npm run launcher` ouvre le nouveau panneau. Si une archive a
perdu les permissions exécutables : `sh start.sh` ou `sh start.command`.

`npm run doctor` vérifie les prérequis sans ouvrir d’identifiants. Un dossier
contenant des espaces est accepté. N’utilisez ni `sudo` ni installation de service.

## Ce qui change en V2

- **Brief** : brief privé éditable et exportable en Markdown ; aucun compte nécessaire.
- Recherche de tokens, sélecteur de couleur, valeurs numériques bornées et brouillon
  récupérable dans le même onglet après recharge. Rien n’est appliqué avant le diff.
- Conflits multi-onglets signalés dans le diff ; session locale renouvelée après
  redémarrage. Les erreurs réseau ne relancent jamais une écriture ambiguë.
- Copie de la révision précédente avant chaque validation ; restauration guidée
  depuis le lanceur, avec archivage de l’original. Aucun reset silencieux.
- Serveur indépendant du panneau, contrôles de fichiers renforcés, tests de crash
  et qualification automatisée sur les trois OS. Les lanceurs natifs restent à
  qualifier sur les postes réels (voir [rapport](DELIVERY_REPORT.md)).

[Changelog V1/V2](docs/V2_CHANGELOG.md) · [Audit et priorités](docs/V2_AUDIT.md)

## Ajouts de la version Gutt (PFE)

- **Claude dans l'atelier** : chat en bulle flottante, choix du modèle et de l'effort,
  jauge des crédits. Il modifie ou **crée des tokens**, compare avec la dernière
  lecture Figma, commente le bilan d'accessibilité et aide pour le PFE, l'école ou le
  travail (réponses mises en forme, bouton Copier). Démarrages rapides quand le chat
  est vide. Les propositions passent toujours par le diff et ta validation.
- **Figma** : bouton Figma de l'en-tête ou Paramètres › Figma. « Lire depuis Figma »
  ouvre un diff ; « Envoyer vers Figma » montre les variables à écrire, puis met à jour
  la collection `DS-Studio` et relit. Voir [FIGMA](docs/FIGMA.md).
- **Tokens ajoutés** : « + Ajouter un token » dans chaque famille (couleurs, typo,
  espacements, formes), badge « Ajouté », suppression par diff. Inclus dans les exports.
- **Interface** : deux panneaux redimensionnables (Design System et Aperçu), menu du
  Design System par catégories repliables (Tokens, Composants, Écrans, Contrôle qualité),
  sélecteur de couleur HEX/RGB/HSL, enregistrement manuel groupé (Ctrl/Cmd + S).
- **Aperçu** : formats 320 à 1440 px ou libre, mockups téléphone, tablette et
  navigateur, mode Fit ou 100 %, et mode Comparer (deux formats côte à côte, ou
  avant / après des modifications en cours).
- **Visite guidée** : au premier lancement, puis avec le bouton « ? » de l'en-tête.
- **Paramètres** (roue crantée) : assistant IA, apparence de l'atelier, connexion et synchro Figma,
  préférences de démarrage, raccourcis et réinitialisation.
- **En-tête** : bouton Brief, puis Historique, Importer et Exporter en icônes.
- **Exports** (valeurs enregistrées uniquement) : Tokens JSON, Variables CSS,
  Tailwind v4, Tailwind v3 et Documentation (page HTML imprimable en PDF).
- **Accessibilité** : dans Couleurs, choix du « Type de vision » (vision classique par
  défaut, malvoyance, deutéranopie, protanopie, tritanopie, sans couleur), statut par couleur et
  proposition appliquée en brouillon. Dans Contrôle qualité › Accessibilité, bilan
  global par profil avec liens « Corriger dans… », et zones cliquables mesurées.

Détail et justification de chaque choix : [DECISIONS](workspace/DECISIONS.md).

## Votre première boucle, en deux minutes

1. Dans **Design System › Couleurs**, remplacez « Couleur de marque » par `#8A3B20`.
   L’aperçu se met à jour tout de suite ; le voyant orange en haut indique « non enregistrée ».
2. Cliquez **Enregistrer (1)** en haut (ou Ctrl/Cmd + S). Le diff montre l’ancienne et la nouvelle valeur, sans écriture.
3. Cliquez **Valider et enregistrer**. Composants et aperçu utilisent la valeur enregistrée.
4. Testez les largeurs 320 à 1440 px dans l’Aperçu, avec ou sans **Ajuster**.
5. Rechargez : la valeur reste. Dans **Historique**, revenez en arrière sur ce changement :
   les autres tokens sont conservés.

La propagation inter-vues utilise les valeurs enregistrées sur disque (diffusion
locale et relecture, au plus environ 1,2 seconde sans diffusion). Aucun rafraîchissement
simulé. Les propositions périmées et annulations conflictuelles sont refusées.

## Où sont mes données ?

| Emplacement                           | Responsabilité                                             |
| ------------------------------------- | ---------------------------------------------------------- |
| `workspace/PFE.md`                    | Votre sujet, publics et objectifs                          |
| `workspace/DESIGN_RULES.md`           | Vos règles de conception et contraintes                    |
| `workspace/DECISIONS.md`              | Vos arbitrages et preuves                                  |
| `workspace/design-system.tokens.json` | Seed versionné, utilisé uniquement à la création d’un état |
| `.ds-studio/project.json`             | Brief PFE privé du panneau, ignoré par Git                 |
| `.ds-studio/state.previous.json`      | Copie de la révision précédente des tokens et du journal   |
| `.ds-studio/state.json`               | Tokens courants et historique personnel, ignorés par Git   |
| `workspace/private/`                  | Vos données privées ignorées, à sauvegarder hors Git       |

Après un incident : arrêtez l’atelier, ouvrez **Journal et réparation** dans le
lanceur puis **Restaurer la copie précédente…**. Une confirmation indique l’effet ;
l’original est conservé sous `state-preserved-….json`. Le brief ne change pas.
Après restauration, rechargez les onglets de l’atelier. Sans copie valide, aucune
restauration automatique n’est tentée. Sauvegardez aussi `.ds-studio/` hors du projet.

Ne modifiez pas le journal `state.json` à la main. L'icône **Exporter** propose le JSON
courant et d'autres formats ; l'icône **Importer** prépare un diff qui demande validation.
Le format est un sous-ensemble local à clés plates et valeurs explicites, **pas un
importeur universel DTCG ni un export Figma automatique**. Voir [TOKENS](docs/TOKENS.md).
Pour sauvegarder tout l’historique, arrêtez le serveur et copiez `.ds-studio/` dans
un emplacement privé. Exporter les tokens seuls ne sauvegarde pas l’historique.

Pour versionner une palette choisie, exportez-la, vérifiez-la puis remplacez le seed
versionné. Cela ne remplace jamais un état courant déjà créé. Ne supprimez pas votre
état pour essayer une autre palette : importez-la ou utilisez un autre dossier de données.

## Travailler avec votre agent préféré

Dans votre CLI (Codex, Claude Code, Gemini CLI, etc.), depuis le dossier du projet :

> Lis START_HERE.md et les instructions de ton agent. Examine le dépôt et mon
> workspace. Aide-moi à définir puis réaliser une amélioration personnelle bornée.
> Préserve mes données et vérifie le résultat. Distingue ce qui est testé de ce qui est proposé.

`AGENTS.md`, `CLAUDE.md` et `GEMINI.md` partagent le même point d’entrée.
Le développement via une CLI externe et le chat embarqué sont **deux choses différentes**.
L’agent externe a ses propres permissions ; DS-Studio ne les contrôle pas.

Codex découvre les skills dans `.agents/skills/` : demandez `$token-change` ou
`$component-audit`. Un autre agent peut lire le `SKILL.md` explicitement. Pour
créer un skill : ajoutez `.agents/skills/nom-du-skill/SKILL.md`, avec un frontmatter
`name` et `description`, puis une procédure courte, ses contraintes et ses preuves.
Inspirez-vous des deux skills fournis, sans copier vos identifiants ou vos conversations.

## État réel de V2

| Fonction                                                            | État et portée                                                                                     |
| ------------------------------------------------------------------- | -------------------------------------------------------------------------------------------------- |
| Édition manuelle, diff, commit, persistance et annulation sélective | **TESTED**, Linux, API + navigateur + redémarrage processus                                        |
| Catalogue et viewport responsive, formulaire et navigation          | **TESTED**, Chromium sous Linux                                                                    |
| Import/export JSON local                                            | **TESTED**, API + navigateur                                                                       |
| Exports CSS, Tailwind et Documentation                              | **TESTED**, tests unitaires + téléchargements navigateur                                           |
| Test d'accessibilité et simulation de la vision des couleurs        | **TESTED**, Chromium ; contrôle sur les tokens, pas un audit WCAG complet de l'app                 |
| Chat Codex, JSON proposé avant acceptation                          | **TESTED**, CLI 0.164.0, compte enseignant disponible pendant la qualification ; quota non garanti |
| Claude Code dans l’application (dont création de tokens)            | **TESTED**, Linux, CLI 2.1.312, sans outils ; essai réel : nouveau token proposé en diff           |
| Gemini dans l’application                                           | **NOT IMPLEMENTED**, adaptateur indisponible et contrat documenté                                  |
| Synchro Figma (MCP officiel via Claude Code)                        | **PARTIAL** : scripts testés sur le vrai fichier, CLI + garde testés ; OAuth sur le Mac à faire    |
| Skills et harness personnalisable                                   | **IMPLEMENTED**, structure et liens vérifiés ; pas une validation des choix d’un étudiant          |
| Qualification automatisée Windows / macOS                           | **TESTED en CI** pour API, navigateur et contrôleur ; **PARTIAL** pour Finder/WSH natifs           |
| Application desktop installable                                     | **NOT IMPLEMENTED**, application web locale uniquement                                             |

Preuves précises et réserves : [DELIVERY_REPORT.md](DELIVERY_REPORT.md).

### Codex embarqué (facultatif)

Le mode est restreint à **Codex CLI 0.164.0** : une autre version est refusée jusqu’à
qualification. Installez cette version depuis les moyens officiels de votre CLI,
puis authentifiez-vous vous-même avec `codex login` et contrôlez `codex login status`.
Aucun fichier d’authentification n’est ouvert ou copié par l’application. Un compte
compatible, une connexion et du quota sont requis. Aucun compte enseignant n’est fourni.

Choisir Codex puis **Envoyer** transmet les tokens, `PFE.md`, `DESIGN_RULES.md`, la demande
et au plus dix messages précédents. Ne mettez pas de données sensibles dans ce contexte.
Le brief privé est également transmis. Le chat ne persiste pas après recharge. Codex ne peut pas exécuter vos commandes dans
ce profil : le contrôleur valide les propositions de tokens, l’utilisateur accepte le diff.
Les MCP, plugins et outils shell sont désactivés, et le contexte est transmis en JSON
depuis un dossier temporaire vide. L’authentification reste gérée par le CLI officiel.
Détails et limites : [SECURITY](docs/SECURITY.md), [AGENTS](docs/AGENT_ADAPTERS.md).

### Figma

Les variables de la collection `DS-Studio` de ton fichier se lisent et se mettent à
jour depuis l’atelier, avec diff et validation dans les deux sens. Connexion une fois
dans Claude Code (`/mcp`), aucun jeton dans l’atelier. Détails, garde-fous et limites
(10 appels par minute, 200 par jour sur le plan Éducation) : [FIGMA](docs/FIGMA.md).

## Vérifier et développer

```sh
npm run doctor
npm run check
npm test
npm run build
npx playwright install chromium
npm run test:e2e
npm run qualify
npm run scan
```

`npm run dev` démarre le backend avec Vite sur la même adresse. `npm start` sert
`dist/` : reconstruisez avec `npm run build` après un changement frontend.
Les tests utilisent des dossiers temporaires et ne touchent pas vos données.
`npm run test:live` et `npm run qualify:live` sont **facultatifs et connectés à Codex** ;
ils peuvent consommer du quota, contrairement aux autres commandes.

## Créer votre dépôt privé

1. Téléchargez le starter sans reprendre de compte partagé. Personnalisez le workspace.
2. Créez vous-même un dépôt **privé** sur GitHub (interface web ou GitHub Desktop).
3. Avec GitHub Desktop, ajoutez ce dossier puis publiez en conservant **Keep this code private**.
   Avec Git, utilisez `git status`, `git add`, `git diff --cached` et `git commit` avant
   d’ajouter votre propre remote et de pousser. Ne réutilisez aucun remote enseignant.
4. Vérifiez les fichiers indexés et lancez `npm run scan` avant le premier envoi.
   Pour un nouveau dépôt non indexé : `git init`, puis `git add .` avant le scan.
5. Gardez `.ds-studio/`, `.env`, identifiants et documents sensibles hors Git. Un dépôt
   privé n’est pas un coffre-fort. `.gitignore` ne retire pas un secret déjà commité.

Le starter est sous [licence MIT](LICENSE) pour le code original ; les dépendances
conservent leurs licences. Aucune copie du code ou des mémoires personnelles de MARC.

## Pour aller plus loin

[Guide étudiant](docs/STUDENT_GUIDE.md) · [Guide enseignant](docs/TEACHER_GUIDE.md) ·
[Architecture](docs/ARCHITECTURE.md) · [Backlog ouvert](docs/ROADMAP.md)
